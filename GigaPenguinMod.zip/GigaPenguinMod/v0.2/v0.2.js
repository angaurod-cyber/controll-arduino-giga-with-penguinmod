/*
  PenguinMod Arduino GIGA v0.2
  Autor: Angel
  Requiere: modo unsandboxed + WebSerial
*/

(async function (Scratch) {
  if (!Scratch.extensions.unsandboxed) {
    alert("Esta extensión requiere modo UNSANDBOXED");
    return;
  }

  // ================= SERIAL =================
  let port = null;
  let reader = null;
  let writer = null;

  async function connect() {
    port = await navigator.serial.requestPort();
    await port.open({ baudRate: 2000000 });

    writer = port.writable.getWriter();
    reader = port.readable.getReader();
    readLoop();
  }

  async function send(line) {
    if (!writer) return;
    const data = new TextEncoder().encode(line + "\n");
    await writer.write(data);
  }

  // ================= ESTADO =================
  let touchX = 0;
  let touchY = 0;
  let lastButton = "";
  let lastDAC0 = 0;
  let lastDAC1 = 0;
  let motion = 0;

  async function readLoop() {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;

      const text = new TextDecoder().decode(value);
      const lines = text.split(/\r?\n/);

      for (const line of lines) {
        if (!line.trim()) continue;

        try {
          const msg = JSON.parse(line);

          if (msg.event === "touch") {
            touchX = msg.x;
            touchY = msg.y;
          }

          if (msg.event === "button") {
            lastButton = msg.id;
          }

          if (typeof msg.dac0 !== "undefined") lastDAC0 = msg.dac0;
          if (typeof msg.dac1 !== "undefined") lastDAC1 = msg.dac1;
          if (typeof msg.motion !== "undefined") motion = msg.motion;

        } catch (e) {
          // ignorar texto no JSON
        }
      }
    }
  }

  // ================= EXTENSION =================
  class GigaExtension {
    getInfo() {
      return {
        id: "gigaGFX",
        name: "Arduino GIGA GFX",
        color1: "#0fb9b1",
        blocks: [

          // -------- Conexión --------
          {
            opcode: "connect",
            text: "conectar Arduino GIGA",
            blockType: Scratch.BlockType.COMMAND
          },

          // -------- Touch --------
          {
            opcode: "getTouchX",
            text: "touch X",
            blockType: Scratch.BlockType.REPORTER
          },
          {
            opcode: "getTouchY",
            text: "touch Y",
            blockType: Scratch.BlockType.REPORTER
          },

          // -------- Botones --------
          {
            opcode: "createButton",
            text: "crear botón id [ID] x [X] y [Y] w [W] h [H] texto [TXT]",
            blockType: Scratch.BlockType.COMMAND,
            arguments: {
              ID: { type: Scratch.ArgumentType.STRING, defaultValue: "btn1" },
              X: { type: Scratch.ArgumentType.NUMBER, defaultValue: 20 },
              Y: { type: Scratch.ArgumentType.NUMBER, defaultValue: 20 },
              W: { type: Scratch.ArgumentType.NUMBER, defaultValue: 120 },
              H: { type: Scratch.ArgumentType.NUMBER, defaultValue: 40 },
              TXT: { type: Scratch.ArgumentType.STRING, defaultValue: "OK" }
            }
          },
          {
            opcode: "buttonPressed",
            text: "botón presionado = [ID]",
            blockType: Scratch.BlockType.BOOLEAN,
            arguments: {
              ID: { type: Scratch.ArgumentType.STRING, defaultValue: "btn1" }
            }
          },

          // -------- DAC --------
          {
            opcode: "dacWrite",
            text: "DAC [PIN] valor [VAL]",
            blockType: Scratch.BlockType.COMMAND,
            arguments: {
              PIN: { type: Scratch.ArgumentType.NUMBER, defaultValue: 66 },
              VAL: { type: Scratch.ArgumentType.NUMBER, defaultValue: 2048 }
            }
          },
          {
            opcode: "getDAC0",
            text: "DAC0",
            blockType: Scratch.BlockType.REPORTER
          },
          {
            opcode: "getDAC1",
            text: "DAC1",
            blockType: Scratch.BlockType.REPORTER
          },

          // -------- Cámara --------
          {
            opcode: "camStart",
            text: "iniciar cámara",
            blockType: Scratch.BlockType.COMMAND
          },
          {
            opcode: "camStop",
            text: "detener cámara",
            blockType: Scratch.BlockType.COMMAND
          },

          // -------- ML --------
          {
            opcode: "motionDetected",
            text: "movimiento detectado",
            blockType: Scratch.BlockType.BOOLEAN
          }
        ]
      };
    }

    // ====== IMPLEMENTACIÓN ======
    connect() { return connect(); }

    // Touch
    getTouchX() { return touchX; }
    getTouchY() { return touchY; }

    // Botones
    createButton(args) {
      send(`btn:${args.ID},${args.X},${args.Y},${args.W},${args.H},${args.TXT}`);
    }

    buttonPressed(args) {
      return lastButton === args.ID;
    }

    // DAC
    dacWrite(args) {
      send(`dac:${args.PIN},${args.VAL}`);
    }

    getDAC0() { return lastDAC0; }
    getDAC1() { return lastDAC1; }

    // Cámara
    camStart() { send("cam:start"); }
    camStop() { send("cam:stop"); }

    // ML
    motionDetected() {
      send("ml:motion");
      return motion === 1;
    }
  }

  Scratch.extensions.register(new GigaExtension());
})(Scratch);
