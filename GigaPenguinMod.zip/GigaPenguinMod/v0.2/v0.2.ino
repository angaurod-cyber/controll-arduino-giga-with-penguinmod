/****************************************************
 * GigaPenguinMod v0.2 (GFX)
 * Autor: Angel
 * Board: Arduino GIGA R1 WiFi
 * Display: Giga Display Shield
 ****************************************************/

#include <Arduino.h>

#include <Arduino_GigaDisplay_GFX.h>
#include <Arduino_GigaDisplayTouch.h>

#include "arducam_dvp.h"
#include "OV7670/ov767x.h"

#include "SDRAM.h"
// ===== Colores RGB565 =====
#define BLACK   0x0000
#define WHITE   0xFFFF
#define RED     0xF800
#define GREEN   0x07E0
#define BLUE    0x001F
#define YELLOW  0xFFE0
#define CYAN    0x07FF
#define MAGENTA 0xF81F


// ================= DISPLAY (GFX) =================
GigaDisplay_GFX gfx;
Arduino_GigaDisplayTouch Touch;

// ================= CAMERA =================
OV7675 ov767x;
Camera cam(ov767x);

#define IMAGE_MODE CAMERA_RGB565

FrameBuffer camFB;

// ================= DAC =================
#define DAC0_PIN A12
#define DAC1_PIN A13
uint16_t lastDAC0 = 0;
uint16_t lastDAC1 = 0;

// ================= TOUCH =================
int touchX = 0;
int touchY = 0;

// ================= BUTTON UI =================
struct UIButton {
  String id;
  int x, y, w, h;
  String text;
};

UIButton buttons[10];
int buttonCount = 0;

// ================= CAMERA CONTROL =================
bool camEnabled = false;
int camRotation = 0;

// ================= ML (simple) =================
bool motionDetected = false;
uint16_t *prevFrame = nullptr;

// ================= SETUP =================
void setup() {
  Serial.begin(2000000);

  // Display
  gfx.begin();
  gfx.fillScreen(BLACK);
  gfx.setTextWrap(false);

  // Touch
  Touch.begin();

  // Camera
  if (!cam.begin(CAMERA_R320x240, IMAGE_MODE, 30)) {
    while (1);
  }

  prevFrame = (uint16_t*)SDRAM.malloc(320 * 240 * 2);

  Serial.println("{\"status\":\"ready\"}");
}

// ================= BUTTON DRAW =================
void drawButton(const UIButton &b) {
  gfx.drawRect(b.x, b.y, b.w, b.h, WHITE);
  gfx.setCursor(b.x + 6, b.y + (b.h / 2) - 8);
  gfx.setTextColor(WHITE);
  gfx.setTextSize(2);
  gfx.print(b.text);
}

// ================= BUTTON CHECK =================
void checkButtons(int x, int y) {
  for (int i = 0; i < buttonCount; i++) {
    if (x >= buttons[i].x &&
        x <= buttons[i].x + buttons[i].w &&
        y >= buttons[i].y &&
        y <= buttons[i].y + buttons[i].h) {

      Serial.println(
        "{\"event\":\"button\",\"id\":\"" + buttons[i].id + "\"}"
      );
    }
  }
}

// ================= ML =================
void detectMotion(uint16_t *buf) {
  int diff = 0;
  for (int i = 0; i < 320 * 240; i += 16) {
    diff += abs((int)buf[i] - (int)prevFrame[i]);
    prevFrame[i] = buf[i];
  }
  motionDetected = diff > 40000;
}

// ================= SERIAL COMMANDS =================
void handleCommand(String cmd) {

  // ---- CAMERA ----
  if (cmd == "cam:start") camEnabled = true;
  else if (cmd == "cam:stop") camEnabled = false;

  // ---- DAC ----
  else if (cmd.startsWith("dac:")) {
    int p = cmd.indexOf(',');
    int pin = cmd.substring(4, p).toInt();
    int val = constrain(cmd.substring(p + 1).toInt(), 0, 4095);

    if (pin == 66) {
      analogWrite(DAC0_PIN, val);
      lastDAC0 = val;
    }
    if (pin == 67) {
      analogWrite(DAC1_PIN, val);
      lastDAC1 = val;
    }

    Serial.println(
      "{\"dac0\":" + String(lastDAC0) +
      ",\"dac1\":" + String(lastDAC1) + "}"
    );
  }

  // ---- BUTTON ----
  else if (cmd.startsWith("btn:")) {
    // btn:id,x,y,w,h,text
    int p[5], idx = 0;
    for (int i = 0; i < cmd.length(); i++)
      if (cmd[i] == ',') p[idx++] = i;

    UIButton &b = buttons[buttonCount++];
    b.id   = cmd.substring(4, p[0]);
    b.x    = cmd.substring(p[0] + 1, p[1]).toInt();
    b.y    = cmd.substring(p[1] + 1, p[2]).toInt();
    b.w    = cmd.substring(p[2] + 1, p[3]).toInt();
    b.h    = cmd.substring(p[3] + 1, p[4]).toInt();
    b.text = cmd.substring(p[4] + 1);

    drawButton(b);
  }

  // ---- ML ----
  else if (cmd == "ml:motion") {
    Serial.println("{\"motion\":" + String(motionDetected) + "}");
  }
}

// ================= LOOP =================
void loop() {

  // ---- TOUCH ----
  GDTpoint_t points[5];
  int count = Touch.getTouchPoints(points);

  if (count > 0) {
    touchX = points[0].x;
    touchY = points[0].y;

    Serial.println(
      "{\"event\":\"touch\",\"x\":" + String(touchX) +
      ",\"y\":" + String(touchY) + "}"
    );

    checkButtons(touchX, touchY);
  }

  // ---- CAMERA ----
  if (camEnabled) {
    if (cam.grabFrame(camFB, 3000) == 0) {
      detectMotion((uint16_t*)camFB.getBuffer());
    }
  }

  // ---- SERIAL ----
  if (Serial.available()) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();
    if (cmd.length()) handleCommand(cmd);
  }
}